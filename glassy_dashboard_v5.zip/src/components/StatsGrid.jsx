import React from 'react';
import { useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { DollarSign, Briefcase, Clock, TrendingUp, ArrowRight } from 'lucide-react';

const iconMap = {
  DollarSign: DollarSign,
  Briefcase: Briefcase,
  Clock: Clock,
  TrendingUp: TrendingUp,
};

export default function StatsGrid() {
  const stats = useSelector((state) => state.dashboard.stats);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((item, index) => {
        const Icon = iconMap[item.icon] || TrendingUp;
        const isPositive = item.change.startsWith('+');

        return (
          <motion.div
            key={index}
            whileHover={{ y: -4 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            className="glass-card p-5 rounded-2xl relative overflow-hidden group"
          >
            <div className={`absolute -right-6 -bottom-6 w-28 h-28 rounded-full bg-gradient-to-br ${item.gradient} blur-2xl group-hover:scale-125 transition-transform duration-500`} />
            
            <div className="flex items-center justify-between mb-4 relative z-10">
              <span className="text-sm font-medium text-slate-300">{item.title}</span>
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white border border-white/10">
                <Icon className="w-5 h-5 text-emerald-400" />
              </div>
            </div>

            <div className="flex items-baseline justify-between relative z-10">
              <h3 className="text-2xl font-bold text-white tracking-tight">{item.value}</h3>
              <div className={`flex items-center gap-1 text-xs font-semibold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                <span>{item.change}</span>
                <ArrowRight className="w-3.5 h-3.5 -rotate-45" />
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
