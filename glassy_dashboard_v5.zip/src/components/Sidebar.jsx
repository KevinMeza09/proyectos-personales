import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { setActiveTab } from '../store/dashboardSlice';
import { LayoutDashboard, MessageSquare, FolderKanban, Bookmark, Settings, LogOut, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Sidebar() {
  const dispatch = useDispatch();
  const activeTab = useSelector((state) => state.dashboard.activeTab);

  const navItems = [
    { id: 'home', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'saved', label: 'Saved', icon: Bookmark },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="glass-sidebar w-20 xl:w-64 h-screen flex flex-col justify-between py-6 px-3 xl:px-6 fixed left-0 top-0 z-40 transition-all duration-300">
      <div>
        {/* Logo / Brand */}
        <div className="flex items-center gap-3 px-2 mb-10">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-bold text-xl">
            <Sparkles className="w-5 h-5 text-slate-950" />
          </div>
          <div className="hidden xl:block">
            <h1 className="font-bold text-lg text-white leading-tight">Glassy V5</h1>
            <p className="text-xs text-slate-400">Workspace</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => dispatch(setActiveTab(item.id))}
                className={`w-full flex items-center gap-4 px-3 py-3 rounded-xl font-medium transition-all duration-200 group relative ${
                  isActive
                    ? 'bg-white/15 text-white shadow-lg shadow-white/5 border border-white/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform duration-200 group-hover:scale-110 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span className="hidden xl:inline text-sm">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute left-0 w-1 h-6 bg-emerald-400 rounded-r-full"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User profile snippet at bottom */}
      <div className="pt-4 border-t border-white/10">
        <div className="flex items-center gap-3 px-2 py-2 rounded-xl bg-white/5 border border-white/10">
          <img
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
            alt="Robert"
            className="w-10 h-10 rounded-full object-cover border border-white/20"
          />
          <div className="hidden xl:block overflow-hidden">
            <p className="text-sm font-semibold text-white truncate">Robert</p>
            <p className="text-xs text-emerald-400 truncate">Online</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
