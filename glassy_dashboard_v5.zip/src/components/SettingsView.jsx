import React from 'react';
import { useSelector } from 'react-redux';
import { Settings, User, Shield, Bell, Palette, Save } from 'lucide-react';

export default function SettingsView() {
  const userProfile = useSelector((state) => state.dashboard.userProfile);

  return (
    <div className="glass-card p-6 rounded-2xl max-w-3xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-400" />
          Workspace Settings
        </h2>
        <p className="text-xs text-slate-400">Customize your Glassy V5 dashboard preferences</p>
      </div>

      <div className="space-y-4">
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <User className="w-5 h-5 text-emerald-400" />
            <div>
              <p className="text-sm font-semibold text-white">Display Name</p>
              <p className="text-xs text-slate-400">{userProfile.name} ({userProfile.title})</p>
            </div>
          </div>
          <button className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors">
            Edit
          </button>
        </div>

        <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Palette className="w-5 h-5 text-emerald-400" />
            <div>
              <p className="text-sm font-semibold text-white">Glassmorphism Intensity</p>
              <p className="text-xs text-slate-400">Blur: 16px, Opacity: 65%</p>
            </div>
          </div>
          <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            Ultra V5
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 text-emerald-400" />
            <div>
              <p className="text-sm font-semibold text-white">Push Notifications</p>
              <p className="text-xs text-slate-400">Receive alerts for completed sprints</p>
            </div>
          </div>
          <input type="checkbox" defaultChecked className="accent-emerald-500 w-4 h-4 cursor-pointer" />
        </div>
      </div>

      <div className="flex justify-end pt-4 border-t border-white/10">
        <button className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-semibold px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-500/20 text-sm">
          <Save className="w-4 h-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
}
