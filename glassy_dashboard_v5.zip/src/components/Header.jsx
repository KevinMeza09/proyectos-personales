import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { setSearchQuery } from '../store/dashboardSlice';
import { Search, Bell, Plus, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Header() {
  const dispatch = useDispatch();
  const searchQuery = useSelector((state) => state.dashboard.searchQuery);
  const userProfile = useSelector((state) => state.dashboard.userProfile);

  return (
    <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
      <div>
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 text-emerald-400 font-medium text-sm mb-1"
        >
          <Sparkles className="w-4 h-4" />
          <span>Glassy Dashboard V5</span>
        </motion.div>
        <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
          Good evening, {userProfile.name}
        </h1>
      </div>

      <div className="flex items-center gap-3">
        {/* Search input */}
        <div className="relative flex-1 md:w-64">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search projects, messages..."
            value={searchQuery}
            onChange={(e) => dispatch(setSearchQuery(e.target.value))}
            className="w-full glass-input rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none transition-all"
          />
        </div>

        {/* Notifications */}
        <button className="glass-card p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-all relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        </button>

        {/* New Item Action Button */}
        <button className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-500/20 transition-all text-sm whitespace-nowrap">
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">New Task</span>
        </button>
      </div>
    </header>
  );
}
