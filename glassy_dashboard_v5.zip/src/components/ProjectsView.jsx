import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { toggleProjectStatus } from '../store/dashboardSlice';
import { FolderKanban, Plus, Users, CheckCircle2 } from 'lucide-react';

export default function ProjectsView() {
  const dispatch = useDispatch();
  const projects = useSelector((state) => state.dashboard.projectsList);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-emerald-400" />
            All Projects & Sprints
          </h2>
          <p className="text-xs text-slate-400">Manage and monitor all active development boards</p>
        </div>
        <button className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-500/20 text-sm">
          <Plus className="w-4 h-4" />
          New Project
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map((project) => (
          <div key={project.id} className="glass-card p-6 rounded-2xl space-y-4 relative overflow-hidden group">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs bg-white/10 text-slate-300 px-2.5 py-1 rounded-full font-medium">
                  {project.category}
                </span>
                <h3 className="text-lg font-bold text-white mt-2">{project.title}</h3>
              </div>
              <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                project.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
              }`}>
                {project.status}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Progress</span>
                <span className="text-white font-semibold">{project.progress}%</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>{project.members} team members</span>
              </div>
              <button
                onClick={() => dispatch(toggleProjectStatus(project.id))}
                className="flex items-center gap-1.5 text-xs font-semibold bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-xl transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Mark {project.status === 'Completed' ? 'Active' : 'Complete'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
