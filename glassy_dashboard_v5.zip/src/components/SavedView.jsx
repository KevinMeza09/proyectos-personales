import React from 'react';
import { useSelector } from 'react-redux';
import { Bookmark, ExternalLink, Calendar } from 'lucide-react';

export default function SavedView() {
  const savedItems = useSelector((state) => state.dashboard.savedItems);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Bookmark className="w-5 h-5 text-emerald-400" />
          Saved Snippets & Resources
        </h2>
        <p className="text-xs text-slate-400">Quick access to your bookmarked design systems and code</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {savedItems.map((item) => (
          <div key={item.id} className="glass-card p-5 rounded-2xl flex flex-col justify-between space-y-4 hover:border-white/20 transition-all">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full font-medium">
                  {item.tag}
                </span>
                <h3 className="font-bold text-white text-base mt-2">{item.title}</h3>
                <p className="text-xs text-slate-400 mt-1">Type: {item.type}</p>
              </div>
              <button className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors">
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                {item.date}
              </span>
              <span className="text-emerald-400 font-medium">Saved to Cloud</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
