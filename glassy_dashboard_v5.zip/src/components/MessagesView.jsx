import React from 'react';
import { useSelector } from 'react-redux';
import { MessageSquare, Send, Phone, Video, MoreVertical } from 'lucide-react';

export default function MessagesView() {
  const messages = useSelector((state) => state.dashboard.messages);
  const [selectedMsg, setSelectedMsg] = React.useState(messages[0]);

  return (
    <div className="glass-card rounded-2xl h-[calc(100vh-12rem)] flex flex-col md:flex-row overflow-hidden border border-white/10">
      {/* Messages Sidebar List */}
      <div className="w-full md:w-80 border-b md:border-b-0 md:border-r border-white/10 flex flex-col h-1/3 md:h-full">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h2 className="font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            Messages
          </h2>
          <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-medium">4 New</span>
        </div>
        <div className="overflow-y-auto flex-1 p-2 space-y-1">
          {messages.map((msg) => (
            <div
              key={msg.id}
              onClick={() => setSelectedMsg(msg)}
              className={`p-3 rounded-xl cursor-pointer transition-all flex items-start gap-3 ${
                selectedMsg.id === msg.id ? 'bg-white/15 border border-white/20 shadow-lg' : 'hover:bg-white/5'
              }`}
            >
              <img src={msg.avatar} alt={msg.sender} className="w-10 h-10 rounded-full object-cover border border-white/20 shrink-0" />
              <div className="overflow-hidden flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-semibold text-white truncate">{msg.sender}</h4>
                  <span className="text-[10px] text-slate-400">{msg.time}</span>
                </div>
                <p className="text-xs text-slate-400 truncate">{msg.preview}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Conversation Area */}
      <div className="flex-1 flex flex-col h-2/3 md:h-full bg-slate-950/20">
        {/* Chat Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
          <div className="flex items-center gap-3">
            <img src={selectedMsg.avatar} alt={selectedMsg.sender} className="w-10 h-10 rounded-full object-cover border border-white/20" />
            <div>
              <h3 className="font-semibold text-white text-sm">{selectedMsg.sender}</h3>
              <p className="text-xs text-emerald-400">Active now</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <button className="p-2 rounded-lg hover:bg-white/10 transition-colors"><Phone className="w-4 h-4" /></button>
            <button className="p-2 rounded-lg hover:bg-white/10 transition-colors"><Video className="w-4 h-4" /></button>
            <button className="p-2 rounded-lg hover:bg-white/10 transition-colors"><MoreVertical className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="flex justify-start">
            <div className="glass-card max-w-md p-3.5 rounded-2xl rounded-tl-sm text-sm text-slate-200">
              {selectedMsg.preview}
            </div>
          </div>
          <div className="flex justify-end">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-medium max-w-md p-3.5 rounded-2xl rounded-tr-sm text-sm shadow-lg shadow-emerald-500/10">
              That's fantastic! I've verified the components and everything looks exceptionally sleek. Let's merge it in.
            </div>
          </div>
        </div>

        {/* Chat Input */}
        <div className="p-4 border-t border-white/10 bg-white/5 flex items-center gap-3">
          <input
            type="text"
            placeholder="Type your message..."
            className="flex-1 glass-input rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none"
          />
          <button className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 p-2.5 rounded-xl font-semibold transition-all shadow-lg shadow-emerald-500/20">
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
