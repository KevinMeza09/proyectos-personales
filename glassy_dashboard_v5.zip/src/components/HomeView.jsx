import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { toggleProjectStatus } from '../store/dashboardSlice';
import StatsGrid from './StatsGrid';
import { CheckCircle2, Clock, ShieldCheck, Activity, Users, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function HomeView() {
  const dispatch = useDispatch();
  const projects = useSelector((state) => state.dashboard.projectsList);

  return (
    <div>
      <StatsGrid />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Projects */}
        <div className="lg:col-span-2 glass-card p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Active Projects</h2>
              <p className="text-xs text-slate-400">Real-time tracking of ongoing V5 sprints</p>
            </div>
            <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-full font-medium">
              4 Active
            </span>
          </div>

          <div className="space-y-4">
            {projects.map((project) => (
              <div 
                key={project.id}
                className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-white/20 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white text-sm">{project.title}</h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      project.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {project.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">{project.category}</p>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-32 bg-white/10 rounded-full h-2 overflow-hidden hidden sm:block">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500" 
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-slate-300 w-9 text-right">{project.progress}%</span>
                  <button
                    onClick={() => dispatch(toggleProjectStatus(project.id))}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                    title="Toggle Status"
                  >
                    <CheckCircle2 className={`w-4 h-4 ${project.status === 'Completed' ? 'text-emerald-400' : 'text-slate-400'}`} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: System Status & Activity */}
        <div className="glass-card p-6 rounded-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-white">System Core</h2>
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>

            <div className="space-y-4 mb-6">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Server Status</p>
                    <p className="text-sm font-semibold text-white">Operational (99.9%)</p>
                  </div>
                </div>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Active Sessions</p>
                    <p className="text-sm font-semibold text-white">1,429 users</p>
                  </div>
                </div>
                <span className="text-xs text-emerald-400 font-medium">+18%</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 text-center">
            <p className="text-xs text-emerald-300 font-medium mb-1">Glassy UI V5 Engine</p>
            <p className="text-xs text-slate-400">Optimized for React 18 & Tailwind 3.4</p>
          </div>
        </div>
      </div>
    </div>
  );
}
