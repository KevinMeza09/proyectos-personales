import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  activeTab: 'home', // 'home', 'messages', 'projects', 'saved', 'settings'
  stats: [
    { title: 'Portfolio Value', value: '$848.2K', change: '+12.4%', icon: 'DollarSign', gradient: 'from-emerald-500/20 to-teal-500/20' },
    { title: 'Active Projects', value: '164', change: '+5.2%', icon: 'Briefcase', gradient: 'from-blue-500/20 to-indigo-500/20' },
    { title: 'Hours Logged', value: '38h', change: '-2.1%', icon: 'Clock', gradient: 'from-purple-500/20 to-pink-500/20' },
    { title: 'Efficiency Rate', value: '98.5%', change: '+4.0%', icon: 'TrendingUp', gradient: 'from-amber-500/20 to-orange-500/20' },
  ],
  messages: [
    { id: 1, sender: 'Eleanor Vance', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', preview: 'Hey Robert! Just reviewed the latest V5 glass UI drafts. Absolutely stunning work!', time: '10:42 AM', unread: true },
    { id: 2, sender: 'Marcus Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', preview: 'The Redux store integration is super smooth. Let me know when you push to main.', time: '09.15 AM', unread: false },
    { id: 3, sender: 'Sophia Loren', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', preview: 'Can we schedule a quick sync regarding the responsive layout breakpoints?', time: 'Yesterday', unread: false },
    { id: 4, sender: 'David Miller', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', preview: 'Client approved the modern glassmorphism aesthetic across all screens!', time: '2 days ago', unread: false },
  ],
  projectsList: [
    { id: 1, title: 'Glassy Dashboard V5 UI', category: 'Frontend Architecture', progress: 85, status: 'In Progress', members: 4 },
    { id: 2, title: 'Neural Core SDK Integration', category: 'Backend & API', progress: 100, status: 'Completed', members: 3 },
    { id: 3, title: 'Immersive Spatial Audio App', category: 'Mobile & Audio', progress: 42, status: 'In Progress', members: 5 },
    { id: 4, title: 'Quantum Compute Dashboard', category: 'Data Visualization', progress: 60, status: 'In Progress', members: 2 },
  ],
  savedItems: [
    { id: 1, title: 'Advanced Tailwind Glass Gradients', type: 'Snippet', tag: 'UI/UX', date: 'Oct 24, 2026' },
    { id: 2, title: 'Redux Toolkit Best Practices Guide', type: 'Documentation', tag: 'State', date: 'Oct 21, 2026' },
    { id: 3, title: 'Framer Motion Spring Physics Config', type: 'Animation', tag: 'Motion', date: 'Oct 18, 2026' },
    { id: 4, title: 'High-Performance React Memoization', type: 'Optimization', tag: 'Performance', date: 'Oct 15, 2026' },
  ],
  userProfile: {
    name: 'Robert',
    title: 'Senior Product Engineer',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    location: 'San Francisco, CA'
  },
  searchQuery: '',
}

export const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    setActiveTab: (state, action) => {
      state.activeTab = action.payload;
    },
    setSearchQuery: (state, action) => {
      state.searchQuery = action.payload;
    },
    toggleProjectStatus: (state, action) => {
      const project = state.projectsList.find(p => p.id === action.payload);
      if (project) {
        project.status = project.status === 'Completed' ? 'In Progress' : 'Completed';
        project.progress = project.status === 'Completed' ? 100 : project.progress;
      }
    }
  },
})

export const { setActiveTab, setSearchQuery, toggleProjectStatus } = dashboardSlice.actions;
export default dashboardSlice.reducer;
