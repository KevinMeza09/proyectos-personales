import React from 'react';
import { useSelector } from 'react-redux';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import HomeView from './components/HomeView';
import MessagesView from './components/MessagesView';
import ProjectsView from './components/ProjectsView';
import SavedView from './components/SavedView';
import SettingsView from './components/SettingsView';

export default function App() {
  const activeTab = useSelector((state) => state.dashboard.activeTab);

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomeView />;
      case 'messages':
        return <MessagesView />;
      case 'projects':
        return <ProjectsView />;
      case 'saved':
        return <SavedView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 relative flex overflow-x-hidden">
      {/* Background ambient lighting/image simulation */}
      <div className="absolute inset-0 z-0 opacity-40 bg-cover bg-center pointer-events-none" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2000&auto=format&fit=crop")' }} />
      <div className="absolute inset-0 z-0 bg-gradient-to-tr from-slate-950 via-slate-950/80 to-transparent pointer-events-none" />

      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Content Area */}
      <main className="flex-1 pl-20 xl:pl-64 min-h-screen p-4 md:p-8 relative z-10">
        <div className="max-w-7xl mx-auto">
          <Header />
          {renderContent()}
        </div>
      </main>
    </div>
  );
}
