document.addEventListener('DOMContentLoaded', () => {
    const daysGrid = document.getElementById('days-grid');
    const timeSlots = document.querySelectorAll('.time-slot');
    const btnConfirm = document.getElementById('btn-confirm');
    const step1 = document.getElementById('step-1');
    const step2 = document.getElementById('step-2');
    const successDetails = document.getElementById('success-details');
    const btnAgain = document.getElementById('btn-again');

    let selectedDay = null;
    let selectedTime = null;

    // Renderizar días del calendario de ejemplo (Noviembre 2026)
    // 30 días, empezando en Domingo/Lunes según diseño
    const totalDays = 30;
    for (let i = 1; i <= totalDays; i++) {
        const dayEl = document.createElement('div');
        dayEl.classList.add('day');
        dayEl.textContent = i;
        
        // Marcar el día 19 por defecto como en el diseño
        if (i === 19) {
            dayEl.classList.add('selected');
            selectedDay = i;
        }

        dayEl.addEventListener('click', () => {
            document.querySelectorAll('.day').forEach(d => d.classList.remove('selected'));
            dayEl.classList.add('selected');
            selectedDay = i;
        });

        daysGrid.appendChild(dayEl);
    }

    // Selección de hora
    timeSlots.forEach(slot => {
        slot.addEventListener('click', () => {
            timeSlots.forEach(s => s.classList.remove('selected'));
            slot.classList.add('selected');
            selectedTime = slot.getAttribute('data-time');
            btnConfirm.removeAttribute('disabled');
        });
    });

    // Confirmar turno
    btnConfirm.addEventListener('click', () => {
        if (selectedDay && selectedTime) {
            successDetails.textContent = `Martes ${selectedDay} de noviembre · ${selectedTime} - ${parseInt(selectedTime) + 1}:00`;
            step1.classList.add('hidden');
            step2.classList.remove('hidden');
        }
    });

    // Agendar otro
    btnAgain.addEventListener('click', () => {
        step2.classList.add('hidden');
        step1.classList.remove('hidden');
        timeSlots.forEach(s => s.classList.remove('selected'));
        btnConfirm.setAttribute('disabled', 'true');
        selectedTime = null;
    });
});
