# Recurso 265 - Formularios: Elige día y hora (Moxen)

Este proyecto es una interfaz moderna e interactiva para la selección de días y horarios de citas o reuniones, basada en el diseño de **Moxen** (`moxen.cl/recursos`).

## Características
- **HTML5 y CSS3 Modernos:** Diseño oscuro elegante, adaptado con variables, CSS Grid y Flexbox.
- **Interactividad con JavaScript:** Selección dinámica de días en el calendario, elección de horarios disponibles, validación de formularios y pantalla de confirmación de reserva.
- **Diseño Responsive:** Optimizado para dispositivos móviles y computadoras de escritorio.

## Estructura del proyecto
```text
├── index.html    # Estructura principal de la interfaz
├── turno.css     # Estilos y diseño visual (modo oscuro)
└── turno.js      # Lógica de selección e interactividad
```

## Cómo usarlo localmente
1. Clona este repositorio o descarga los archivos.
2. Abre el archivo `index.html` en tu navegador web preferido.

---
Diseño original por [Moxen](https://moxen.cl).
